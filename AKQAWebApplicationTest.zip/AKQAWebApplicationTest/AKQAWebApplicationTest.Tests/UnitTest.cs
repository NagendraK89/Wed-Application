﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Web.Http;
using AKQAWebApplicationTest.Controllers;
using AKQAWebApplicationTest.Models;

namespace AKQAWebApplicationTest.Tests
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestSuccess()
        {
            var input = new Input();
            input = new Input { Name = "test", Amount = Convert.ToDecimal(123.45) };
            var controller = new ShowResultsController();
            string result;
            ShowResultsController ctrl = new ShowResultsController();
            ctrl.Request = new HttpRequestMessage();
            ctrl.Configuration = new HttpConfiguration();
            HttpResponseMessage httpResponseMessage = ctrl.Show(input);
            httpResponseMessage.TryGetContentValue<string>(out result);
            Assert.AreEqual(result, "test , one hundred and twenty-three dollars and forty-five cents");
        }
        [TestMethod]
        public void TestFail()
        {
            var input = new Input();
            input = new Input { Name = "test", Amount = Convert.ToDecimal(23.45) };
            var controller = new ShowResultsController();
            string result;
            ShowResultsController ctrl = new ShowResultsController();
            ctrl.Request = new HttpRequestMessage();
            ctrl.Configuration = new HttpConfiguration();
            HttpResponseMessage httpResponseMessage = ctrl.Show(input);
            httpResponseMessage.TryGetContentValue<string>(out result);
            Assert.AreNotEqual(result, "Name: test , Amount: one hundred and twenty-three dollars and forty-five cents");
        }
    }
}
